<?
include "obfuscate.php";
?>

<title>Welcome to MISchedule!</title>

<body>
<p style='border-bottom:1px solid black'><img src='title.gif'>
</p>

<table cellspacing=5>
<tr>

<td valign=top>


<td valign=top>
    <blockquote>
    <h2>MISchedule Source Code Released!</h2>
    <blockquote>
    <span style='color:000066;font-family:arial;font-size:12pt;'>
    <p>The MIschedule source code has been released under the GNU Public Licence. <a href="MISchedule.zip">Click here</a>
    to download the original release of the code. If you would like
    to participate in any way with the developement of MIschedule, please contact me at <span style='color:blue'><?=obfuscate('mschedule@umich.edu')?></span>.
    I plan to host a repository where edits to the source code can be stored if there is interest.
    </span>
     
    </blockquote>

    </table>

</table>

<blockquote>MISchedule was originally created by Dan Hostetler and Alex Makris. It has been modified by <a href="http://www.kylemulka.com/">Kyle Mulka</a> to work with the new <a href="http://wolverineaccess.umich.edu/">Wolverine Access</a>. If you have questions, e-mail <span style='color:blue'><?=obfuscate('mschedule@umich.edu')?></span>



