<?php

class Book
{
    var $sections;
    var $title;    
    var $ISBN;
    var $required;
}
?>