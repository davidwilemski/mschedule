<?
$debug = true;

//url to start spider
$start_url = "http://www.umich.edu/~regoff/timesched/winter/";
$correct_pwd = "arf";
?>