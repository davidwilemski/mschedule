<pre>
This page is for updates on the development of MIschedule.

Refresh every 5 minutes or so if you want to watch...
If the page takes a while to load, don't load it over and over please, thanks

I have the data in my database, but now I need to get the data in the for that MIschedule's database wants it and to put it there





<hr>

divisions are loaded! check it out!
courses I think are done, let me know if there are problems with those
stupid problem with the dental school and UP 990 fixed : file: 69.txt (coinsidence??)
on to sections, meetings, and locations.... oh my!

<?
require "v20/php/reloaddbfromfiles.php";


?>
